#' Get family names to make Phylomatic input object, and output input string
#'    to Phylomatic for use in the function phylomatic_tree.
#'
#' THIS FUNCTION IS DEFUNCT.
#'
#' @export
#' @rdname phylomatic_format-defunct
#' @param ... Parameters, ignored
phylomatic_format <- function(...) {
  .Defunct(msg = "This function is defunct - See ?`taxize-defunct`")
}
