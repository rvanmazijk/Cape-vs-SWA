#' A light wrapper around the taxonstand fxn to call Theplantlist.org database.
#'
#' THIS FUNCTION IS DEFUNCT.
#'
#' @export
#' @rdname tpl_search-defunct
tpl_search <- function() {
  .Defunct(msg = "This function is defunct. Use the Taxonstand functions TPL or TPLck directly.")
}
