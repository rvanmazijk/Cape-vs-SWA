#' Check invasive species status for a set of species from GISD database
#'
#' THIS FUNCTION IS DEFUNCT.
#'
#' @export
#' @rdname gisd_invasive-defunct
#' @keywords internal
gisd_isinvasive <- function(...) {
  .Defunct("gisd", "originr", msg = "This function is defunct. See originr::gisd()")
}
