eol_url <- function(x) sprintf('http://eol.org/api/%s/1.0', x)
