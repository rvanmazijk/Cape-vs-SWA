#' Retrieve the taxonomic hierarchy from given EOL taxonID.
#'
#' THIS FUNCTION IS DEFUNCT.
#'
#' @export
#' @rdname eol_hierarchy-defunct
#' @keywords internal
eol_hierarchy <- function(...) {
  .Defunct(msg = "This function is defunct. See classification().")
}
