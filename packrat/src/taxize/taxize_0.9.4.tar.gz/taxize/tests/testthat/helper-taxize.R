sw <- function(x) suppressWarnings(x)
