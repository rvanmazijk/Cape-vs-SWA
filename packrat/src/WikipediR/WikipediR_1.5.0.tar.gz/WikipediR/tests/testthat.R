library(WikipediR)
library(testthat)
test_check("WikipediR")
