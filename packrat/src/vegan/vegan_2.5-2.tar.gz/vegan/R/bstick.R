`bstick` <-
function(n, ...) UseMethod("bstick")

