library(testthat)
library(WikidataR)

test_check("WikidataR")
