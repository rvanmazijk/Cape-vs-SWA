# pandoc-mnras

A template for building MNRAS Journal articles in pandoc.
