library(testit)

test_pkg("rticles")
